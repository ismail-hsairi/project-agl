

<?php $__env->startSection('content'); ?>
    <h1>Listes des Reclamations</h1>
   
    <?php if(count($reclamations) > 0): ?>
        <?php $__currentLoopData = $reclamations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reclamation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-5">
            <div class="card-header">
            By :<?php echo e($reclamation->name); ?>

            </div>
            <div class="card-body">
              <h5 class="card-title">Subject: <?php echo e($reclamation->sujet); ?></h5>
              <p class="card-text">Description: <?php echo e($reclamation->desc); ?></p>
              <hr>
              
              <a href="<?php echo e(route('user.reclamations.show', $reclamation->id)); ?>" class="btn btn-primary">Check this reclamation</a>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    <?php else: ?>
        <h2 class="text-center">Aucune Reclamation</h2>
    <?php endif; ?>
 
  
    
    

 
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\agl-master (3)\agl-master\AGLApp-master\AGLApp-master\resources\views/user/reclamations/index.blade.php ENDPATH**/ ?>