
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Reclamation</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('user.reclamations.store')); ?>">
                        <?php echo csrf_field(); ?>  
           
                     
                        <div class="form-group row">
                        <label for="type" class="col-md-4 col-form-label text-md-right">Type of Reclaim :</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="type"  id="typee" rows="3" value="Technical" disabled="disabled" >
                            </div>
                            
                        </div>
                        
                   
                        
                        <input type="text" name="type" id="type"  style="display: none">

                        <div class="form-group row" hidden=true id="hide">

                        <label for="delivery_number" class="col-md-4 col-form-label text-md-right">Delivery Number </label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="delivery_number" value="" id="delivery_number" rows="3" >
                            </div>
                       </div>
                      <div class="form-group row">
                            <label for="sujet" class="col-md-4 col-form-label text-md-right">Subject </label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="sujet" id="sujet" rows="3" required autofocus>
                            </div>
                        
                        </div> 
                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">Descreption</label>

                            <div class="col-md-6">
                                <textarea class="form-control" name="descreption" id="descreption" rows="3" required autofocus></textarea>
                            </div>
                        </div>        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Add Reclamation
                                </button>
                            </div>
                        </div>
                        
                    </form>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Projet AGL\AGL\AGLApp-master\resources\views/user/reclamations/create_tech.blade.php ENDPATH**/ ?>