

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-role')): ?>
    <a href="<?php echo e(route('user.reclamations.index')); ?>" class="btn btn-danger">Go Back</a>
<?php endif; ?>  
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['applicant-role','giver-role','delivery-man-role'])): ?>
    <a href="<?php echo e(route('user.reclamations.index_rec')); ?>" class="btn btn-danger">Go Back</a>
<?php endif; ?>  
    <h1>Type : <?php echo e($reclamation->type); ?></h1>
    <h4>By :<?php echo e($reclamation->name); ?></h4>
<?php if($reclamation->type != 'Technique'): ?>
    <h4>Delivery number : <?php echo e($reclamation->delivery_id); ?></h4>
<?php endif; ?>
    <h4>Subjcet : <?php echo e($reclamation->sujet); ?></h4>
    <div>
       Description: <?php echo $reclamation->desc; ?>

    </div>
    
    <hr>
    <small>Written on <?php echo e($reclamation->created_at); ?><br></small>
    </hr>
    <?php if(auth()->guard()->check()): ?>
       
            <?php if(Auth::user()->id == $reclamation->user): ?>
                <a href="<?php echo e(route('user.reclamations.edit', $reclamation->id)); ?>"><button type="button" class="btn btn-success btn-lg float-left">Edit</button></a>
                <form action="<?php echo e(route('user.reclamations.destroy', $reclamation->id)); ?>" method="POST" class="float-right">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-lg btn-secondary">Delete</button>
                </form>    
         
       
        <?php endif; ?>
            
            
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Projet AGL\AGL\AGLApp-master\resources\views/user/reclamations/show.blade.php ENDPATH**/ ?>