<?php $__env->startSection('content'); ?>
    <div class="card text-center mb-5">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['applicant-role','giver-role','delivery-man-role'])): ?>
                <!-- Button trigger modal -->
                <a href="<?php echo e(route('user.reclamations.create')); ?>" class="btn btn-primary">Add Reclaim </a>  
            <?php endif; ?>
        <div class="card-header">
        Delivery Man
        </div>
        <div class="card-body">
        <h5 class="card-title">Delivery Man Infos</h5>
        <div class="row">
            <div class="col-md-6">
              <p>Name : </p>
              <p>Email : </p>
              <p>Tel : </p>
              <p>Region : </p>
            </div>

            <div class="col-md-6">
              <p><?php echo e($delivery->user->name); ?></p>
              <p><?php echo e($delivery->user->email); ?></p>
              <p><?php echo e($delivery->user->tel); ?></p>
              <p><?php echo e($delivery->user->region); ?></p>
            </div>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delivery-man-role')): ?>
            <form method="POST" action="<?php echo e(route('contact.delivery.handleChaking', $delivery)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                <button type="submit" class="btn btn-primary">Verify Delivery</button>
            </form>
        <?php endif; ?>
            
        </div>
        <div class="card-footer text-muted">
        2 days ago
        </div>
    </div>

    <div class="card text-center mb-5">
        <div class="card-header">
          Giver
        </div>
        <div class="card-body">
          <h5 class="card-title">Special title treatment</h5>
          <div class="row">
              <div class="col-md-6">
                <p>Name : </p>
                <p>Email : </p>
                <p>Tel : </p>
                <p>Region : </p>
              </div>

              <div class="col-md-6">
                <?php if($delivery->reservation->donation->followed == 1): ?>
                    <p><?php echo e($delivery->reservation->donation->user->name); ?></p>
                    <p><?php echo e($delivery->reservation->donation->user->email); ?></p>
                    <p><?php echo e($delivery->reservation->donation->user->tel); ?></p>
                    <p><?php echo e($delivery->reservation->donation->user->region); ?></p>    
                <?php else: ?>
                <p>Anonymous</p>
                <p>admin@gmail.com</p>
                <p>xx xxx xxx</p>
                <p>anonymous</p>    
                <?php endif; ?>
                
              </div>
          </div>
          
        </div>
        <div class="card-footer text-muted">
          <?php echo e($delivery->created_at); ?>

        </div>
      </div>

      <div class="card text-center mb-5">
        <div class="card-header">
            Applicant
        </div>
        <div class="card-body">
          <h5 class="card-title">Special title treatment</h5>
          <div class="row">
            <div class="col-md-6">
              <p>Name : </p>
              <p>Email : </p>
              <p>Tel : </p>
              <p>Region : </p>
            </div>

            <div class="col-md-6">
              <p><?php echo e($delivery->reservation->demand->user->name); ?></p>
              <p><?php echo e($delivery->reservation->demand->user->email); ?></p>
              <p><?php echo e($delivery->reservation->demand->user->tel); ?></p>
              <p><?php echo e($delivery->reservation->demand->user->region); ?></p>
            </div>
        </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicant-role')): ?>
                <form method="POST" action="<?php echo e(route('contact.delivery.handleChaking', $delivery)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <button type="submit" class="btn btn-primary">Verify Delivery</button>
                </form>    
            <?php endif; ?>
            
        </div>
        <div class="card-footer text-muted">
          2 days ago
        </div>
      </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\agl-master (3)\agl-master\AGLApp-master\AGLApp-master\resources\views/contact/deliveries/interior_delivery.blade.php ENDPATH**/ ?>