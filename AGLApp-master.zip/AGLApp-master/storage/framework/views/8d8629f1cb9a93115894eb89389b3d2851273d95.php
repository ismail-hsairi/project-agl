<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1>Welcome to our App</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea dolor dolores itaque! Nisi assumenda magni, fuga saepe veritatis soluta sed maiores eveniet amet adipisci libero! Distinctio pariatur excepturi illum perspiciatis.</p>
        <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> <a class="btn btn-success btn-lg" href="/register" role="button">Register</a></p>
    </div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\AGLApp-master\AGLApp-master\resources\views/pages/index.blade.php ENDPATH**/ ?>