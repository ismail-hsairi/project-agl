<?php $__env->startSection('content'); ?>
    <h1>Listes des Donts</h1>
    <?php if(count($donations) > 0): ?>
        <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-5">
            <div class="card-header">
              <?php echo e($donation->item->subject->name); ?>

            </div>
            <div class="card-body">
              <h5 class="card-title">Item: <?php echo e($donation->item->name); ?></h5>
              <p class="card-text">Availability: <?php echo e($donation->availability); ?></p>
              <hr>
    
              <a href="<?php echo e(route('giver.donations.show', $donation)); ?>" class="btn btn-primary">Check this donation</a>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    <?php else: ?>
        <h2 class="text-center">Aucune demande a traiter</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Projet AGL\AGLApp-master\resources\views/giver/donations/index.blade.php ENDPATH**/ ?>